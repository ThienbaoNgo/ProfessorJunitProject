
import java.util.Scanner;

public class TNgo_Assignment1_Moss {
	
	/*
	 * Integrity Pledge: I pledge that I have completed the programming assignment independently. 

 I have not copied the code from a student or any source. 

Student’s Name: Thienbao Ngo 
	 */
	
	public static void main(String[] args) {
		
		System.out.println("If you have a problem with internet connectivity, this WiFi Diagnosis might work. \nFirst step: Reboot the computer and try to connect." + "\n" + "Did that work? (yes or no)"); 
		
		Scanner someScanner = new Scanner(System.in);
		
		//instantiate scanner
		
		String answer = someScanner.nextLine();
		
		//Read the response to every print statement into the parameters for the if statement.
		
		if(answer.compareToIgnoreCase("no") == 0){
			
			//Any other answer then no will be treated as a yes.
			
			System.out.println("Second step: Reboot the router and try to connect." + "\n" + "Did that work? (yes or no)"); 

				answer = someScanner.nextLine(); 

			if(answer.compareToIgnoreCase("no") == 0){ 

			System.out.println("Third step: Make sure the cables for the router and power plug are firmly plugged in." + "\n" + "Did that work? (yes or no)"); 

					answer = someScanner.nextLine(); 

					if(answer.compareToIgnoreCase("no") == 0){ 

						System.out.println("Fourth step: Move the computer closer to the router and try to connect." + "\n" + "Did that work? (yes or no)"); 

						answer = someScanner.nextLine(); 

								if(answer.compareToIgnoreCase("no") == 0){ 

									System.out.println("Fifth step: Contact your ISP." + "\n" + "Make sure your ISP is hooked up to your router."); 
										
								} 

						else{System.out.println("Great, moving closer worked");
						//Dead end
						} 

			} 

			else{System.out.println("Great, plugging it in worked.");
			//Dead end
			} 

			} 

			else{System.out.println("Great, rebooting the router worked.");
			//Dead end
			} 

			 

			 

			} 

			else{System.out.print("Great, rebooting the computer worked.");
			//Dead end
			} 
		
		
	}
	
}
